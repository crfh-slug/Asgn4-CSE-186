from py4web import action, request, DAL, Field, Session

session = Session()

@action("index")
@action.uses(session)
def index():
    session["counter"] = session.get("counter", 0) + 1
    return f"Hello World {session['counter']}"
